G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-25T23:50:42+06:00*
G04 #@! TF.ProjectId,merope3_plate,6d65726f-7065-4335-9f70-6c6174652e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-25 23:50:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
